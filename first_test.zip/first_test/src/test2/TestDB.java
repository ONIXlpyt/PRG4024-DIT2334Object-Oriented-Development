package test2;


import java.sql.*;

public class TestDB {
    public static void main(String[] args) {
        String sql = "SELECT code, name, requires_lab FROM course";
        try (Connection con = DBConnection.get();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            System.out.println("Connected!");
            while (rs.next()) {
                System.out.println(rs.getString("code") + " " + rs.getString("name")
                        + " lab=" + rs.getBoolean("requires_lab"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}