package test2;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;            // NEW (database)
import java.sql.PreparedStatement;     // NEW (database)
import java.sql.ResultSet;             // NEW (database)
import java.sql.SQLException;          // NEW (database)
import java.sql.Statement;             // NEW (database)
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/*
 * TimetableStore: ALL the timetable logic lives here. It never prints and never reads input,
 * so the console menu (TimetableApp) and the future GUI can both use it unchanged.
 *
 * Items in the lists are picked by their position (index 0, 1, 2...) in the matching *Lines() list.
 *
 * Layout of this file:
 *   A. Data held by the store
 *   B. PUBLIC METHODS  (what TimetableApp / the GUI call)
 *   C. Result and listener types used by the public methods
 *   D. Internal classes (model, repository, checker, strategies, csv)  -- private, not visible outside
 */
public class TimetableStore {

    // ======================
    //  A. SETTINGS AND DATA
    // ======================

    /** Limits on how many lecturers and student groups can be registered. */
    public static final int MAX_LECTURERS = 6;
    public static final int MAX_GROUPS = 6;

    /** Auto-generate leaves at least this many hours between two classes of the same group or lecturer. */
    public static final int BREAK_HOURS = 1;

    private final Repository<Course> courses = new Repository<Course>();
    private final Repository<Lecturer> lecturers = new Repository<Lecturer>();
    private final Repository<StudentGroup> groups = new Repository<StudentGroup>();
    private final Repository<Room> rooms = new Repository<Room>();
    private final Timetable timetable = new Timetable();
    private final ConflictChecker checker = new ConflictChecker();
    private final List<SessionRequest> requests = new ArrayList<SessionRequest>();


    // ==================
    //  B. PUBLIC METHODS
    // ==================

    // show master data 

    public List<String> courseLines()   { return describe(courses.findAll()); }
    public List<String> lecturerLines() { return describe(lecturers.findAll()); }
    public List<String> groupLines()    { return describe(groups.findAll()); }
    public List<String> roomLines()     { return describe(rooms.findAll()); }

    //courses: add / remove 

    /** Adds a course and returns its index. Throws IllegalArgumentException for empty input or a duplicate code. */
    public int addCourse(String code, String name, boolean needsLab) {
        code = code.trim().toUpperCase();
        name = name.trim();
        if (code.isEmpty() || name.isEmpty()) throw new IllegalArgumentException("code and name cannot be empty");
        Course c = new Course(code, name, needsLab);
        courses.add(c);
        try { Db.insertCourse(c); } catch (RuntimeException e) { courses.remove(c.getId()); throw e; }   // CHANGED: also saves to DB
        return courses.findAll().size() - 1;
    }

    /** How many scheduled sessions + pending requests will also be deleted if this course is removed. */
    public int courseImpact(int index) {
        Course c = at(courses.findAll(), index, "course");
        int n = timetable.countByCourse(c);
        for (SessionRequest r : requests) if (r.course.getId().equals(c.getId())) n++;
        return n;
    }

    /** Removes the course AND its scheduled sessions and pending requests. Returns the removed course code. */
    public String removeCourse(int index) {
        Course c = at(courses.findAll(), index, "course");
        Db.deleteCourse(c.getId());   // CHANGED: delete from DB first (cascades its sessions/requests)
        timetable.removeByCourse(c);
        Iterator<SessionRequest> it = requests.iterator();
        while (it.hasNext()) if (it.next().course.getId().equals(c.getId())) it.remove();
        courses.remove(c.getId());
        return c.code;
    }

    //lecturers: add / remove

    /**
     * Adds a lecturer and returns the index.
     * Throws IllegalArgumentException for empty input, a duplicate ID, or when MAX_LECTURERS is reached.
     */
    public int addLecturer(String id, String name) {
        id = id.trim().toUpperCase();
        name = name.trim();
        if (id.isEmpty() || name.isEmpty()) throw new IllegalArgumentException("ID and name cannot be empty");
        if (lecturers.findAll().size() >= MAX_LECTURERS)
            throw new IllegalArgumentException("maximum of " + MAX_LECTURERS + " lecturers reached (remove one first)");
        Lecturer l = new Lecturer(id, name);
        lecturers.add(l);
        try { Db.insertLecturer(l); } catch (RuntimeException e) { lecturers.remove(l.getId()); throw e; }   // CHANGED: also saves to DB
        return lecturers.findAll().size() - 1;
    }

    /** How many scheduled sessions + pending requests will also be deleted if this lecturer is removed. */
    public int lecturerImpact(int index) {
        Lecturer l = at(lecturers.findAll(), index, "lecturer");
        int n = timetable.countByLecturer(l);
        for (SessionRequest r : requests) if (r.lecturer.getId().equals(l.getId())) n++;
        return n;
    }

    /** Removes the lecturer AND their scheduled sessions and pending requests. Returns the removed lecturer ID. */
    public String removeLecturer(int index) {
        Lecturer l = at(lecturers.findAll(), index, "lecturer");
        Db.deleteLecturer(l.getId());   // CHANGED: delete from DB first
        timetable.removeByLecturer(l);
        Iterator<SessionRequest> it = requests.iterator();
        while (it.hasNext()) if (it.next().lecturer.getId().equals(l.getId())) it.remove();
        lecturers.remove(l.getId());
        return l.getId();
    }

    // student groups: add / remove 

    /**
     * Adds a student group and returns the index.
     * Throws IllegalArgumentException for empty input, a size below 1, a duplicate ID, or when MAX_GROUPS is reached.
     */
    public int addGroup(String id, int size) {
        id = id.trim().toUpperCase();
        if (id.isEmpty()) throw new IllegalArgumentException("group ID cannot be empty");
        if (size < 1) throw new IllegalArgumentException("group size must be at least 1");
        if (groups.findAll().size() >= MAX_GROUPS)
            throw new IllegalArgumentException("maximum of " + MAX_GROUPS + " student groups reached (remove one first)");
        StudentGroup g = new StudentGroup(id, size);
        groups.add(g);
        try { Db.insertGroup(g); } catch (RuntimeException e) { groups.remove(g.getId()); throw e; }   // CHANGED: also saves to DB
        return groups.findAll().size() - 1;
    }

    /** How many scheduled sessions + pending requests will also be deleted if this group is removed. */
    public int groupImpact(int index) {
        StudentGroup g = at(groups.findAll(), index, "group");
        int n = timetable.countByGroup(g);
        for (SessionRequest r : requests) if (r.group.getId().equals(g.getId())) n++;
        return n;
    }

    /** Removes the group AND its scheduled sessions and pending requests. Returns the removed group ID. */
    public String removeGroup(int index) {
        StudentGroup g = at(groups.findAll(), index, "group");
        Db.deleteGroup(g.getId());   // CHANGED: delete from DB first
        timetable.removeByGroup(g);
        Iterator<SessionRequest> it = requests.iterator();
        while (it.hasNext()) if (it.next().group.getId().equals(g.getId())) it.remove();
        groups.remove(g.getId());
        return g.getId();
    }

    // ---------- rooms: add / remove / assign to courses (NEW) ----------

    /** Adds a room and returns its index. Throws IllegalArgumentException for empty input, capacity < 1 or duplicate ID. */
    public int addRoom(String id, String name, int capacity, boolean isLab) {
        id = id.trim().toUpperCase();
        name = name.trim();
        if (id.isEmpty() || name.isEmpty()) throw new IllegalArgumentException("ID and name cannot be empty");
        if (capacity < 1) throw new IllegalArgumentException("capacity must be at least 1");
        Room room = isLab ? new Laboratory(id, name, capacity) : new Room(id, name, capacity);
        rooms.add(room);
        try { Db.insertRoom(room); } catch (RuntimeException e) { rooms.remove(room.getId()); throw e; }   // saves to DB
        return rooms.findAll().size() - 1;
    }

    /** How many scheduled sessions will also be deleted if this room is removed. */
    public int roomImpact(int index) {
        return timetable.countByRoom(at(rooms.findAll(), index, "room"));
    }

    /** Removes the room, its scheduled sessions, and its course assignments. Returns the removed room ID. */
    public String removeRoom(int index) {
        Room r = at(rooms.findAll(), index, "room");
        Db.deleteRoom(r.getId());   // delete from DB first (cascades its sessions and course assignments)
        timetable.removeByRoom(r);
        for (Course c : courses.findAll()) c.assignedRooms.remove(r);
        rooms.remove(r.getId());
        return r.getId();
    }

    /** Assigns a room to a course (auto-generate then only uses the assigned rooms for that course). */
    public void assignRoom(int courseIndex, int roomIndex) {
        Course c = at(courses.findAll(), courseIndex, "course");
        Room r = at(rooms.findAll(), roomIndex, "room");
        if (c.assignedRooms.contains(r)) throw new IllegalArgumentException(r.getName() + " is already assigned to " + c.code);
        if (c.requiresLab && !r.isLab()) throw new IllegalArgumentException(c.code + " needs a laboratory, " + r.getName() + " is not one");
        Db.insertCourseRoom(c.getId(), r.getId());   // saves to DB
        c.assignedRooms.add(r);
    }

    public void unassignRoom(int courseIndex, int roomIndex) {
        Course c = at(courses.findAll(), courseIndex, "course");
        Room r = at(rooms.findAll(), roomIndex, "room");
        if (!c.assignedRooms.contains(r)) throw new IllegalArgumentException(r.getName() + " is not assigned to " + c.code);
        Db.deleteCourseRoom(c.getId(), r.getId());   // saves to DB
        c.assignedRooms.remove(r);
    }

    /** One line per course, e.g. "DMS4013 Databases  ->  Computer Lab 1". */
    public List<String> assignmentLines() {
        List<String> lines = new ArrayList<String>();
        for (Course c : courses.findAll()) {
            StringBuilder sb = new StringBuilder(c.code + " " + c.name + "  ->  ");
            if (c.assignedRooms.isEmpty()) sb.append("(any room)");
            for (int i = 0; i < c.assignedRooms.size(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(c.assignedRooms.get(i).getName());
            }
            lines.add(sb.toString());
        }
        return lines;
    }

    // ---------- auto-generate requests ----------

    /** A request tells auto-generate which lecturer teaches which group for how many hours (1-10). */
    public void addRequest(int courseIndex, int lecturerIndex, int groupIndex, int hours) {
        if (hours < 1 || hours > 10) throw new IllegalArgumentException("hours must be between 1 and 10");
        SessionRequest req = new SessionRequest(
                at(courses.findAll(), courseIndex, "course"),
                at(lecturers.findAll(), lecturerIndex, "lecturer"),
                at(groups.findAll(), groupIndex, "group"), hours);
        Db.insertRequest(req);   // CHANGED: also saves to DB
        requests.add(req);
    }

    public int requestCount() { return requests.size(); }

    //  add a class session (with conflict check) 

    /**
     * Validates the session and saves it only if there are no conflicts.
     * Returns the list of conflict messages: EMPTY means the session was saved.
     * Throws IllegalArgumentException for a bad day or time.
     */
    public List<String> addSession(int courseIndex, int lecturerIndex, int groupIndex, int roomIndex,
                                   String day, String start, String end) {
        DayOfWeek d;
        try {
            d = DayOfWeek.valueOf(day.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("day must be MONDAY, TUESDAY, WEDNESDAY, THURSDAY or FRIDAY");
        }
        TimeSlot slot = new TimeSlot(d, parseTime(start), parseTime(end));
        ClassSession s = new ClassSession(
                at(courses.findAll(), courseIndex, "course"),
                at(lecturers.findAll(), lecturerIndex, "lecturer"),
                at(groups.findAll(), groupIndex, "group"),
                at(rooms.findAll(), roomIndex, "room"), slot);

        List<String> conflicts = checker.validate(s, timetable);      // <-- the conflict check
        if (conflicts.isEmpty()) { Db.insertSession(s); timetable.add(s); }   // CHANGED: also saves to DB
        return conflicts;
    }

    //  auto-generate 

    /** Names of the available strategies, in order (index 0 = First-Fit, 1 = Balanced-Load). */
    public static List<String> strategyNames() {
        List<String> names = new ArrayList<String>();
        for (SchedulingStrategy s : strategies()) names.add(s.toString());
        return names;
    }

    /**
     * Clears the timetable, then places every request with the chosen strategy. progress may be null.
     * Classes of the same group or lecturer are kept at least BREAK_HOURS apart.
     */
    public ScheduleResult generate(int strategyIndex, ProgressListener progress) {
        SchedulingStrategy strategy = at(strategies(), strategyIndex, "strategy");
        timetable.clear();
        ScheduleResult result = strategy.schedule(requests, timetable, checker, rooms.findAll(), progress);
        Db.replaceSessions(timetable.all());   // CHANGED: save the generated timetable to DB
        return result;
    }

    /** Same as generate(), but runs on a background thread and waits for it to finish. */
    public ScheduleResult generateInBackground(final int strategyIndex, final ProgressListener progress)
            throws InterruptedException {
        final ScheduleResult[] holder = new ScheduleResult[1];
        Thread worker = new Thread(new Runnable() {
            public void run() { holder[0] = generate(strategyIndex, progress); }
        }, "timetable-worker");
        worker.start();
        worker.join();
        return holder[0];
    }

    /** Clears the whole timetable (memory + database). Returns how many sessions were deleted. */
    public int clearTimetable() {
        int n = timetable.all().size();
        Db.update("DELETE FROM class_session");   // DB first: if this fails, memory stays unchanged
        timetable.clear();
        return n;
    }

    //  view and export the timetable 

    public int sessionCount() { return timetable.all().size(); }

    public static String[] timetableHeaders() {
        return new String[]{"Day", "Time", "Course", "Lecturer", "Room", "Group"};
    }

    /** One String[] per session (same order as timetableHeaders()), sorted by day then start time. */
    public List<String[]> timetableRows() {
        List<String[]> rows = new ArrayList<String[]>();
        for (ClassSession s : timetable.sorted())
            rows.add(new String[]{s.slot.day.toString(), s.slot.start + "-" + s.slot.end,
                    s.course.code, s.lecturer.getName(), s.room.getName(), s.group.id});
        return rows;
    }

    /** Writes the timetable to a CSV file and returns the file. Throws IOException if it cannot be written. */
    public File exportCsv(String fileName) throws IOException {
        return CsvExporter.export(timetable, fileName);
    }

    //  starting data 

    /** Loads example courses, lecturers, groups, rooms and requests. Edit this to match your own data. */
    public void loadSampleData() {
        Course prog = new Course("PRG4013", "Programming", true);
        Course db   = new Course("DMS4013", "Databases", true);
        Course net  = new Course("DIT4014", "Networking", false);
        Course math = new Course("MTH4013", "Discrete Maths", false);
        courses.add(prog);
        courses.add(db);
        courses.add(net);
        courses.add(math);

        Lecturer Umi = new Lecturer("L1", "Ms Umi");
        Lecturer Ariff  = new Lecturer("L2", "Sir Ariff");
        Lecturer Zarina = new Lecturer("L3", "Ms Zarina");
        Umi.block(new TimeSlot(DayOfWeek.FRIDAY, LocalTime.of(8, 0), LocalTime.of(18, 0)));      // no Fridays
        lecturers.add(Umi);
        lecturers.add(Ariff);
        lecturers.add(Zarina);

        StudentGroup g1 = new StudentGroup("G1", 30);
        StudentGroup g2 = new StudentGroup("G2", 25);
        groups.add(g1);
        groups.add(g2);

        Room hall  = new Room("R1", "Lecture Hall 1", 40);
        Room room2 = new Room("R2", "Room 2", 28);
        Room lab1  = new Laboratory("LAB1", "Computer Lab 1", 30);
        room2.block(new TimeSlot(DayOfWeek.WEDNESDAY, LocalTime.of(12, 0), LocalTime.of(14, 0))); // maintenance
        rooms.add(hall);
        rooms.add(room2);
        rooms.add(lab1);

        // hard coded 
        requests.add(new SessionRequest(prog, Umi, g1, 2));
        requests.add(new SessionRequest(prog, Umi, g2, 2));
        requests.add(new SessionRequest(db, Ariff, g1, 2));
        requests.add(new SessionRequest(db, Ariff, g2, 2));
        requests.add(new SessionRequest(net, Zarina, g1, 2));
        requests.add(new SessionRequest(math, Zarina, g2, 2));
    }

    //NEW: load everything from the database (use this instead of loadSampleData)

    /** Loads courses, lecturers, groups, rooms, blocked times, room assignments, requests and sessions from MySQL. */
    public void loadFromDatabase() {
        courses.clear(); lecturers.clear(); groups.clear(); rooms.clear();
        requests.clear(); timetable.clear();
        Map<String, Course> cm = new LinkedHashMap<String, Course>();
        Map<String, Lecturer> lm = new LinkedHashMap<String, Lecturer>();
        Map<String, StudentGroup> gm = new LinkedHashMap<String, StudentGroup>();
        Map<String, Room> rm = new LinkedHashMap<String, Room>();
        try (Connection con = DBConnection.get()) {
            for (String[] r : Db.rows(con, "SELECT code, name, requires_lab FROM course")) {
                Course c = new Course(r[0], r[1], Db.isTrue(r[2]));
                courses.add(c);
                cm.put(c.getId(), c);
            }
            for (String[] r : Db.rows(con, "SELECT id, name FROM lecturer")) {
                Lecturer l = new Lecturer(r[0], r[1]);
                lecturers.add(l);
                lm.put(l.getId(), l);
            }
            for (String[] r : Db.rows(con, "SELECT lecturer_id, day, start_time, end_time FROM lecturer_blocked ORDER BY id"))
                lm.get(r[0]).block(Db.slot(r[1], r[2], r[3]));
            for (String[] r : Db.rows(con, "SELECT id, size FROM student_group")) {
                StudentGroup g = new StudentGroup(r[0], Integer.parseInt(r[1]));
                groups.add(g);
                gm.put(g.getId(), g);
            }
            for (String[] r : Db.rows(con, "SELECT id, name, capacity, is_lab FROM room")) {
                int cap = Integer.parseInt(r[2]);
                Room room = Db.isTrue(r[3]) ? new Laboratory(r[0], r[1], cap) : new Room(r[0], r[1], cap);
                rooms.add(room);
                rm.put(room.getId(), room);
            }
            for (String[] r : Db.rows(con, "SELECT room_id, day, start_time, end_time FROM room_blocked ORDER BY id"))
                rm.get(r[0]).block(Db.slot(r[1], r[2], r[3]));
            for (String[] r : Db.rows(con, "SELECT course_code, room_id FROM course_room"))
                cm.get(r[0]).assignedRooms.add(rm.get(r[1]));
            for (String[] r : Db.rows(con, "SELECT course_code, lecturer_id, group_id, hours FROM session_request ORDER BY id"))
                requests.add(new SessionRequest(cm.get(r[0]), lm.get(r[1]), gm.get(r[2]), Integer.parseInt(r[3])));
            for (String[] r : Db.rows(con, "SELECT course_code, lecturer_id, group_id, room_id, day, start_time, end_time "
                    + "FROM class_session ORDER BY id"))
                timetable.add(new ClassSession(cm.get(r[0]), lm.get(r[1]), gm.get(r[2]), rm.get(r[3]),
                        Db.slot(r[4], r[5], r[6])));
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot load from the database: " + e.getMessage(), e);
        }
    }

    //  small private helpers 

    private static <T> List<String> describe(List<T> items) {
        List<String> lines = new ArrayList<String>();
        for (T item : items) lines.add(item.toString());
        return lines;
    }

    private static <T> T at(List<T> list, int index, String what) {
        if (index < 0 || index >= list.size()) throw new IllegalArgumentException("no such " + what);
        return list.get(index);
    }

    /** Accepts "9:00" or "09:00". */
    private static LocalTime parseTime(String text) {
        String t = text.trim();
        if (t.length() == 4) t = "0" + t;
        try {
            return LocalTime.parse(t);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("time must look like 09:00 (HH:mm), not \"" + text.trim() + "\"");
        }
    }

    private static List<SchedulingStrategy> strategies() {
        return Arrays.<SchedulingStrategy>asList(new FirstFitStrategy(), new BalancedLoadStrategy());
    }


    // ==========================================================
    //  C. RESULT AND LISTENER TYPES (used by the public methods)
    // ==========================================================

    /** Called by generate() as it works, with 0-100. */
    public interface ProgressListener {
        void onProgress(int percent);
    }

    /** What generate() returns. */
    public static class ScheduleResult {
        private final List<ClassSession> placed = new ArrayList<ClassSession>();
        private final List<SessionRequest> unscheduled = new ArrayList<SessionRequest>();

        public int placedCount() { return placed.size(); }
        public int unscheduledCount() { return unscheduled.size(); }

        /** e.g. "CS101 / G2" for each request that could not be placed. */
        public List<String> unscheduledLabels() {
            List<String> labels = new ArrayList<String>();
            for (SessionRequest r : unscheduled) labels.add(r.course.code + " / " + r.group.id);
            return labels;
        }
    }


    // ============================================================
    //  D. INTERNAL CLASSES  (private: only this file can use them)
    // ============================================================

    //  model 

    private interface Identifiable {
        String getId();
    }

    private static class TimeSlot {
        final DayOfWeek day;
        final LocalTime start, end;

        TimeSlot(DayOfWeek day, LocalTime start, LocalTime end) {
            if (!start.isBefore(end)) throw new IllegalArgumentException("start time must be before end time");
            this.day = day;
            this.start = start;
            this.end = end;
        }

        /** Back-to-back (A ends when B starts) is NOT an overlap. */
        boolean overlaps(TimeSlot o) {
            return day == o.day && start.isBefore(o.end) && o.start.isBefore(end);
        }

        public String toString() { return day + " " + start + "-" + end; }
    }

    /** Base class for Lecturer and Room: both can have blocked periods (leave, maintenance). */
    private static abstract class Resource implements Identifiable {
        private final String id, name;
        private final List<TimeSlot> blocked = new ArrayList<TimeSlot>();

        Resource(String id, String name) { this.id = id; this.name = name; }

        public String getId() { return id; }
        String getName() { return name; }
        void block(TimeSlot s) { blocked.add(s); }

        boolean isAvailable(TimeSlot s) {
            for (TimeSlot b : blocked) if (b.overlaps(s)) return false;
            return true;
        }

        public String toString() { return id + " " + name; }
    }

    private static class Lecturer extends Resource {
        Lecturer(String id, String name) { super(id, name); }
    }

    private static class Room extends Resource {
        private final int capacity;

        Room(String id, String name, int capacity) { super(id, name); this.capacity = capacity; }

        int getCapacity() { return capacity; }
        boolean isLab() { return false; }

        public String toString() { return super.toString() + " (cap " + capacity + (isLab() ? ", LAB)" : ")"); }
    }

    private static class Laboratory extends Room {
        Laboratory(String id, String name, int capacity) { super(id, name, capacity); }

        boolean isLab() { return true; }
    }

    private static class Course implements Identifiable {
        final String code, name;
        final boolean requiresLab;

        // NEW: rooms assigned to this course (empty = any room)
        private final List<Room> assignedRooms = new ArrayList<Room>();

        Course(String code, String name, boolean requiresLab) {
            this.code = code;
            this.name = name;
            this.requiresLab = requiresLab;
        }

        /** NEW: rooms assigned to this course, or all rooms if none are assigned. */
        List<Room> roomsOrAll(List<Room> all) { return assignedRooms.isEmpty() ? all : assignedRooms; }

        public String getId() { return code; }
        public String toString() { return code + " " + name + (requiresLab ? " [needs lab]" : ""); }
    }

    private static class StudentGroup implements Identifiable {
        final String id;
        final int size;

        StudentGroup(String id, int size) { this.id = id; this.size = size; }

        public String getId() { return id; }
        public String toString() { return id + " (" + size + " students)"; }
    }

    private static class ClassSession {
        final Course course;
        final Lecturer lecturer;
        final StudentGroup group;
        final Room room;
        final TimeSlot slot;

        ClassSession(Course course, Lecturer lecturer, StudentGroup group, Room room, TimeSlot slot) {
            this.course = course;
            this.lecturer = lecturer;
            this.group = group;
            this.room = room;
            this.slot = slot;
        }
    }

    /** What auto generation must place: a course taught by a lecturer to a group for N hours. */
    private static class SessionRequest {
        final Course course;
        final Lecturer lecturer;
        final StudentGroup group;
        final int hours;

        SessionRequest(Course course, Lecturer lecturer, StudentGroup group, int hours) {
            this.course = course;
            this.lecturer = lecturer;
            this.group = group;
            this.hours = hours;
        }
    }

    //  generic repository (one class reused for every entity type) 

    private static class Repository<T extends Identifiable> {
        private final Map<String, T> store = new LinkedHashMap<String, T>();

        synchronized void add(T item) {
            if (store.containsKey(item.getId())) throw new IllegalArgumentException("Duplicate ID: " + item.getId());
            store.put(item.getId(), item);
        }

        synchronized boolean remove(String id) { return store.remove(id) != null; }
        synchronized List<T> findAll() { return new ArrayList<T>(store.values()); }
        synchronized void clear() { store.clear(); }   // NEW (used by loadFromDatabase)
    }

    //  timetable 

    private static class Timetable {
        private final List<ClassSession> sessions = Collections.synchronizedList(new ArrayList<ClassSession>());

        void add(ClassSession s) { sessions.add(s); }
        void clear() { sessions.clear(); }

        int countByCourse(Course c) {
            int n = 0;
            for (ClassSession s : all()) if (s.course.getId().equals(c.getId())) n++;
            return n;
        }

        int countByLecturer(Lecturer l) {
            int n = 0;
            for (ClassSession s : all()) if (s.lecturer.getId().equals(l.getId())) n++;
            return n;
        }

        int countByGroup(StudentGroup g) {
            int n = 0;
            for (ClassSession s : all()) if (s.group.getId().equals(g.getId())) n++;
            return n;
        }

        // NEW
        int countByRoom(Room r) {
            int n = 0;
            for (ClassSession s : all()) if (s.room.getId().equals(r.getId())) n++;
            return n;
        }

        void removeByGroup(StudentGroup g) {
            synchronized (sessions) {
                Iterator<ClassSession> it = sessions.iterator();
                while (it.hasNext()) if (it.next().group.getId().equals(g.getId())) it.remove();
            }
        }

        void removeByCourse(Course c) {
            synchronized (sessions) {
                Iterator<ClassSession> it = sessions.iterator();
                while (it.hasNext()) if (it.next().course.getId().equals(c.getId())) it.remove();
            }
        }

        void removeByLecturer(Lecturer l) {
            synchronized (sessions) {
                Iterator<ClassSession> it = sessions.iterator();
                while (it.hasNext()) if (it.next().lecturer.getId().equals(l.getId())) it.remove();
            }
        }

        // NEW
        void removeByRoom(Room r) {
            synchronized (sessions) {
                Iterator<ClassSession> it = sessions.iterator();
                while (it.hasNext()) if (it.next().room.getId().equals(r.getId())) it.remove();
            }
        }

        /** Snapshot of all sessions (safe to read while a background thread is writing). */
        List<ClassSession> all() {
            synchronized (sessions) { return new ArrayList<ClassSession>(sessions); }
        }

        /** Sessions sorted by day, then start time. */
        List<ClassSession> sorted() {
            List<ClassSession> list = all();
            Collections.sort(list, new Comparator<ClassSession>() {
                public int compare(ClassSession a, ClassSession b) {
                    int d = a.slot.day.compareTo(b.slot.day);
                    return d != 0 ? d : a.slot.start.compareTo(b.slot.start);
                }
            });
            return list;
        }
    }

    //  conflict checker (each rule returns a message, or null if OK) 

    private static class ConflictChecker {

        /** HC7: operating hours 08:00-18:00 */
        String checkOperatingHours(ClassSession n) {
            if (n.slot.start.isBefore(LocalTime.of(8, 0)) || n.slot.end.isAfter(LocalTime.of(16, 30)))
                return "Outside operating hours (08:00-16:30): " + n.slot;
            return null;
        }

        /** HC6: lecturer and room availability */
        String checkAvailability(ClassSession n) {
            if (!n.lecturer.isAvailable(n.slot)) return "Lecturer " + n.lecturer.getName() + " is unavailable at " + n.slot;
            if (!n.room.isAvailable(n.slot)) return "Room " + n.room.getName() + " is unavailable at " + n.slot;
            return null;
        }

        /** HC1: lecturer overlap */
        String checkLecturerOverlap(ClassSession n, Timetable t) {
            for (ClassSession s : t.all())
                if (s.lecturer.getId().equals(n.lecturer.getId()) && s.slot.overlaps(n.slot))
                    return "Lecturer " + n.lecturer.getName() + " already teaches " + s.course.code + " at " + s.slot;
            return null;
        }

        /** HC2: student-group overlap */
        String checkGroupOverlap(ClassSession n, Timetable t) {
            for (ClassSession s : t.all())
                if (s.group.getId().equals(n.group.getId()) && s.slot.overlaps(n.slot))
                    return "Group " + n.group.id + " already attends " + s.course.code + " at " + s.slot;
            return null;
        }

        /** HC3: room / lab overlap */
        String checkRoomOverlap(ClassSession n, Timetable t) {
            for (ClassSession s : t.all())
                if (s.room.getId().equals(n.room.getId()) && s.slot.overlaps(n.slot))
                    return "Room " + n.room.getName() + " is already booked for " + s.course.code + " at " + s.slot;
            return null;
        }

        /** HC4: room capacity */
        String checkCapacity(ClassSession n) {
            if (n.room.getCapacity() < n.group.size)
                return "Room " + n.room.getName() + " seats " + n.room.getCapacity()
                     + " but " + n.group.id + " has " + n.group.size;
            return null;
        }

        /** HC5: laboratory requirement */
        String checkLabRequirement(ClassSession n) {
            if (n.course.requiresLab && !n.room.isLab())
                return n.course.code + " requires a laboratory, but " + n.room.getName() + " is not one";
            return null;
        }

        /** Runs every check and returns ALL problems (an empty list means the session is valid). */
        List<String> validate(ClassSession n, Timetable t) {
            String[] results = {
                checkOperatingHours(n), checkAvailability(n),
                checkLecturerOverlap(n, t), checkGroupOverlap(n, t), checkRoomOverlap(n, t),
                checkCapacity(n), checkLabRequirement(n)
            };
            List<String> problems = new ArrayList<String>();
            for (String r : results) if (r != null) problems.add(r);
            return problems;
        }
    }

    //  scheduling strategies (two ways to auto-place sessions) 

    private static abstract class SchedulingStrategy {
        static final List<DayOfWeek> WEEKDAYS = Arrays.asList(DayOfWeek.MONDAY, DayOfWeek.TUESDAY,
                DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY);

        /** Which days to try first. */
        abstract List<DayOfWeek> dayOrder(SessionRequest r, Timetable t);

        /** Which rooms to try first. */
        abstract List<Room> roomOrder(List<Room> rooms);

        ScheduleResult schedule(List<SessionRequest> requests, Timetable t, ConflictChecker cc,
                                List<Room> rooms, ProgressListener progress) {
            ScheduleResult result = new ScheduleResult();
            int done = 0;
            for (SessionRequest r : new ArrayList<SessionRequest>(requests)) {
                ClassSession s = place(r, t, cc, rooms);
                if (s != null) { t.add(s); result.placed.add(s); }
                else result.unscheduled.add(r);
                done++;
                if (progress != null) progress.onProgress(done * 100 / requests.size());
            }
            return result;
        }

        /**
         * Tries day / hour / room combinations and returns the first one that passes every check
         * AND leaves a break (BREAK_HOURS) before and after for the same group and lecturer.
         */
        private ClassSession place(SessionRequest r, Timetable t, ConflictChecker cc, List<Room> rooms) {
            if (r.hours < 1) return null;
            for (DayOfWeek d : dayOrder(r, t))
                for (int h = 8; h + r.hours <= 18; h++)
                    for (Room room : roomOrder(r.course.roomsOrAll(rooms))) {   // CHANGED: uses the course's assigned rooms
                        ClassSession c = new ClassSession(r.course, r.lecturer, r.group, room,
                                new TimeSlot(d, LocalTime.of(h, 0), LocalTime.of(h + r.hours, 0)));
                        if (cc.validate(c, t).isEmpty() && keepsBreak(c, t)) return c;
                    }
            return null;
        }

        /**
         * True if no other class of the same group or lecturer starts less than BREAK_HOURS after this one
         * ends, or ends less than BREAK_HOURS before it starts. Works by widening the slot by the break on
         * both sides and checking for overlaps. A gap of exactly BREAK_HOURS is allowed.
         */
        private boolean keepsBreak(ClassSession c, Timetable t) {
            TimeSlot widened = new TimeSlot(c.slot.day,
                    c.slot.start.minusHours(BREAK_HOURS), c.slot.end.plusHours(BREAK_HOURS));
            for (ClassSession s : t.all())
                if ((s.group.getId().equals(c.group.getId()) || s.lecturer.getId().equals(c.lecturer.getId()))
                        && s.slot.overlaps(widened)) return false;
            return true;
        }
    }

    /** Takes the first valid slot: Monday first, earliest hour first, rooms in the given order. */
    private static class FirstFitStrategy extends SchedulingStrategy {
        List<DayOfWeek> dayOrder(SessionRequest r, Timetable t) { return WEEKDAYS; }
        List<Room> roomOrder(List<Room> rooms) { return rooms; }

        public String toString() { return "First-Fit"; }
    }

    /** Prefers the least-loaded day for the lecturer/group, and the smallest suitable room. */
    private static class BalancedLoadStrategy extends SchedulingStrategy {

        List<DayOfWeek> dayOrder(final SessionRequest r, final Timetable t) {
            List<DayOfWeek> days = new ArrayList<DayOfWeek>(WEEKDAYS);
            Collections.sort(days, new Comparator<DayOfWeek>() {
                public int compare(DayOfWeek a, DayOfWeek b) { return load(a) - load(b); }

                int load(DayOfWeek d) {
                    int n = 0;
                    for (ClassSession s : t.all())
                        if (s.slot.day == d && (s.lecturer.getId().equals(r.lecturer.getId())
                                             || s.group.getId().equals(r.group.getId()))) n++;
                    return n;
                }
            });
            return days;
        }

        List<Room> roomOrder(List<Room> rooms) {
            List<Room> sorted = new ArrayList<Room>(rooms);
            Collections.sort(sorted, new Comparator<Room>() {
                public int compare(Room a, Room b) { return a.getCapacity() - b.getCapacity(); }
            });
            return sorted;
        }

        public String toString() { return "Balanced-Load"; }
    }

    //  csv export 

    private static class CsvExporter {

        static File export(Timetable timetable, String fileName) throws IOException {
            File file = new File(fileName);
            PrintWriter out = new PrintWriter(file, "UTF-8");
            try {
                out.println("Day,Start,End,Course Code,Course Name,Lecturer,Group,Room");
                for (ClassSession s : timetable.sorted()) {
                    out.println(join(s.slot.day.toString(), s.slot.start.toString(), s.slot.end.toString(),
                            s.course.code, s.course.name, s.lecturer.getName(), s.group.id, s.room.getName()));
                }
            } finally {
                out.close();
            }
            return file;
        }

        private static String join(String... fields) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < fields.length; i++) {
                if (i > 0) sb.append(',');
                sb.append(escape(fields[i]));
            }
            return sb.toString();
        }

        /** Wraps a field in quotes if it contains a comma, quote or line break (doubling any quotes). */
        private static String escape(String field) {
            if (field.indexOf(',') >= 0 || field.indexOf('"') >= 0 || field.indexOf('\n') >= 0)
                return "\"" + field.replace("\"", "\"\"") + "\"";
            return field;
        }
    }

    //  database (NEW): every save / delete goes through here. Connection comes from DBConnection.get().

    private static class Db {

        private static final String INSERT_SESSION = "INSERT INTO class_session "
                + "(course_code, lecturer_id, group_id, room_id, day, start_time, end_time) VALUES (?, ?, ?, ?, ?, ?, ?)";

        /** Runs one INSERT / DELETE with ? parameters. Any SQL problem becomes an IllegalStateException. */
        static void update(String sql, Object... params) {
            try (Connection con = DBConnection.get(); PreparedStatement ps = con.prepareStatement(sql)) {
                for (int i = 0; i < params.length; i++) ps.setObject(i + 1, params[i]);
                ps.executeUpdate();
            } catch (SQLException e) {
                throw new IllegalStateException("Database error: " + e.getMessage(), e);
            }
        }

        /** Runs a SELECT and returns every row as an array of Strings. */
        static List<String[]> rows(Connection con, String sql) throws SQLException {
            List<String[]> list = new ArrayList<String[]>();
            try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
                int n = rs.getMetaData().getColumnCount();
                while (rs.next()) {
                    String[] row = new String[n];
                    for (int i = 0; i < n; i++) row[i] = rs.getString(i + 1);
                    list.add(row);
                }
            }
            return list;
        }

        static boolean isTrue(String s) { return "1".equals(s) || "true".equalsIgnoreCase(s); }

        static TimeSlot slot(String day, String start, String end) {
            return new TimeSlot(DayOfWeek.valueOf(day), LocalTime.parse(start), LocalTime.parse(end));
        }

        static void insertCourse(Course c) {
            update("INSERT INTO course (code, name, requires_lab) VALUES (?, ?, ?)", c.code, c.name, c.requiresLab);
        }
        static void deleteCourse(String id) { update("DELETE FROM course WHERE code = ?", id); }

        static void insertLecturer(Lecturer l) {
            update("INSERT INTO lecturer (id, name) VALUES (?, ?)", l.getId(), l.getName());
        }
        static void deleteLecturer(String id) { update("DELETE FROM lecturer WHERE id = ?", id); }

        static void insertGroup(StudentGroup g) {
            update("INSERT INTO student_group (id, size) VALUES (?, ?)", g.id, g.size);
        }
        static void deleteGroup(String id) { update("DELETE FROM student_group WHERE id = ?", id); }

        static void insertRoom(Room r) {
            update("INSERT INTO room (id, name, capacity, is_lab) VALUES (?, ?, ?, ?)",
                    r.getId(), r.getName(), r.getCapacity(), r.isLab());
        }
        static void deleteRoom(String id) { update("DELETE FROM room WHERE id = ?", id); }

        static void insertCourseRoom(String courseCode, String roomId) {
            update("INSERT INTO course_room (course_code, room_id) VALUES (?, ?)", courseCode, roomId);
        }
        static void deleteCourseRoom(String courseCode, String roomId) {
            update("DELETE FROM course_room WHERE course_code = ? AND room_id = ?", courseCode, roomId);
        }

        static void insertRequest(SessionRequest r) {
            update("INSERT INTO session_request (course_code, lecturer_id, group_id, hours) VALUES (?, ?, ?, ?)",
                    r.course.getId(), r.lecturer.getId(), r.group.getId(), r.hours);
        }

        static void insertSession(ClassSession s) {
            update(INSERT_SESSION, s.course.getId(), s.lecturer.getId(), s.group.getId(), s.room.getId(),
                    s.slot.day.toString(), s.slot.start.toString(), s.slot.end.toString());
        }

        /** Replaces ALL saved sessions with the given list, in one transaction (all or nothing). */
        static void replaceSessions(List<ClassSession> sessions) {
            try (Connection con = DBConnection.get()) {
                con.setAutoCommit(false);
                try {
                    try (Statement st = con.createStatement()) { st.executeUpdate("DELETE FROM class_session"); }
                    try (PreparedStatement ps = con.prepareStatement(INSERT_SESSION)) {
                        for (ClassSession s : sessions) {
                            ps.setString(1, s.course.getId());
                            ps.setString(2, s.lecturer.getId());
                            ps.setString(3, s.group.getId());
                            ps.setString(4, s.room.getId());
                            ps.setString(5, s.slot.day.toString());
                            ps.setString(6, s.slot.start.toString());
                            ps.setString(7, s.slot.end.toString());
                            ps.addBatch();
                        }
                        ps.executeBatch();
                    }
                    con.commit();
                } catch (SQLException e) {
                    con.rollback();
                    throw e;
                }
            } catch (SQLException e) {
                throw new IllegalStateException("Database error: " + e.getMessage(), e);
            }
        }
    }
}