package test2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL =
        "jdbc:mysql://localhost:3306/timetable_db?useSSL=false&serverTimezone=Asia/Kuala_Lumpur";
    private static final String USER = "root";
    private static final String PASSWORD = "";   // XAMPP default is empty

    public static Connection get() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}