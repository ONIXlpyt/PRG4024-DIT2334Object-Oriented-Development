package test2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.File;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

/*
 * TimetableGUI: the Swing window. Like TimetableApp it only asks questions and shows results;
 * all the timetable logic is in TimetableStore.java (same public methods as the console version).
 *
 * Window layout:
 *   top     = menu bar (File / Manage / Timetable / Help)
 *   left    = sidebar with one button per function
 *   centre  = tabs: "Timetable" (table) and "Master data" (courses, lecturers, groups, rooms)
 *   bottom  = status bar (counts) + progress bar (used while auto-generating)
 *
 * Layout of this file:
 *   1. Window parts (menu bar, sidebar, centre, status bar)
 *   2. Actions (one per button / menu item)
 *   3. Small dialog helpers
 *   4. main()   <-- run this
 */
public class TimetableGUI extends JFrame {

    private static final long serialVersionUID = 1L;

    private final TimetableStore store = new TimetableStore();

    private DefaultTableModel tableModel;
    private final DefaultListModel<String> courseModel = new DefaultListModel<String>();
    private final DefaultListModel<String> lecturerModel = new DefaultListModel<String>();
    private final DefaultListModel<String> groupModel = new DefaultListModel<String>();
    private final DefaultListModel<String> roomModel = new DefaultListModel<String>();
    private final DefaultListModel<String> assignmentModel = new DefaultListModel<String>();   // NEW

    private final JLabel statusLabel = new JLabel(" ");
    private final JProgressBar progressBar = new JProgressBar(0, 100);
    private final JComboBox<String> strategyBox = new JComboBox<String>(
            TimetableStore.strategyNames().toArray(new String[0]));

    private boolean busy = false;   // true while auto-generate is running


    public TimetableGUI() {
        super("Academic Timetabling System");
        try {
            store.loadFromDatabase();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Cannot load from the database:\n" + e.getMessage()
                    + "\n\nStart MySQL in XAMPP and check DBConnection.java.", "Database error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setJMenuBar(buildMenuBar());
        add(buildSidebar(), BorderLayout.WEST);
        add(buildCentre(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);

        refresh();
        setSize(1000, 600);
        setLocationRelativeTo(null);
    }


    // =================
    //  1. WINDOW PARTS
    // =================

    //  top menu bar 
    private JMenuBar buildMenuBar() {
        JMenuBar bar = new JMenuBar();

        JMenu file = new JMenu("File");
        file.add(menuItem("Export timetable to CSV...", new Runnable() { public void run() { exportCsv(); } }));
        file.addSeparator();
        file.add(menuItem("Exit", new Runnable() { public void run() { System.exit(0); } }));

        JMenu manage = new JMenu("Manage");
        manage.add(menuItem("Add course...", new Runnable() { public void run() { addCourse(); } }));
        manage.add(menuItem("Remove course...", new Runnable() { public void run() { removeCourse(); } }));
        manage.addSeparator();
        manage.add(menuItem("Add lecturer...", new Runnable() { public void run() { addLecturer(); } }));
        manage.add(menuItem("Remove lecturer...", new Runnable() { public void run() { removeLecturer(); } }));
        manage.addSeparator();
        manage.add(menuItem("Add student group...", new Runnable() { public void run() { addGroup(); } }));
        manage.add(menuItem("Remove student group...", new Runnable() { public void run() { removeGroup(); } }));
        manage.addSeparator();
        // NEW: room functions
        manage.add(menuItem("Add room...", new Runnable() { public void run() { addRoom(); } }));
        manage.add(menuItem("Remove room...", new Runnable() { public void run() { removeRoom(); } }));
        manage.add(menuItem("Assign room to course...", new Runnable() { public void run() { assignRoom(-1); } }));
        manage.add(menuItem("Unassign room from course...", new Runnable() { public void run() { unassignRoom(); } }));
        manage.addSeparator();
        manage.add(menuItem("Add auto-generate request...", new Runnable() { public void run() { addRequest(-1, -1); } }));

        JMenu timetable = new JMenu("Timetable");
        timetable.add(menuItem("Add class session...", new Runnable() { public void run() { addSession(); } }));
        timetable.add(menuItem("Auto-generate", new Runnable() { public void run() { generate(); } }));
        timetable.add(menuItem("Clear timetable...", new Runnable() { public void run() { clearTimetable(); } }));

        JMenu help = new JMenu("Help");
        help.add(menuItem("About", new Runnable() { public void run() { about(); } }));

        bar.add(file);
        bar.add(manage);
        bar.add(timetable);
        bar.add(help);
        return bar;
    }

    private JMenuItem menuItem(String text, final Runnable action) {
        JMenuItem item = new JMenuItem(text);
        item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) { runIfIdle(action); }
        });
        return item;
    }

    //  left sidebar
    private JPanel buildSidebar() {
        JPanel side = new JPanel();
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        side.setBackground(new Color(0xEEF1F5));
        side.setPreferredSize(new Dimension(210, 0));

        side.add(sideHeader("COURSES"));
        side.add(sideButton("Add course", new Runnable() { public void run() { addCourse(); } }));
        side.add(sideButton("Remove course", new Runnable() { public void run() { removeCourse(); } }));

        side.add(sideHeader("LECTURERS (max " + TimetableStore.MAX_LECTURERS + ")"));
        side.add(sideButton("Add lecturer", new Runnable() { public void run() { addLecturer(); } }));
        side.add(sideButton("Remove lecturer", new Runnable() { public void run() { removeLecturer(); } }));

        side.add(sideHeader("STUDENT GROUPS (max " + TimetableStore.MAX_GROUPS + ")"));
        side.add(sideButton("Add student group", new Runnable() { public void run() { addGroup(); } }));
        side.add(sideButton("Remove student group", new Runnable() { public void run() { removeGroup(); } }));

        // NEW: rooms section
        side.add(sideHeader("ROOMS"));
        side.add(sideButton("Add room", new Runnable() { public void run() { addRoom(); } }));
        side.add(sideButton("Remove room", new Runnable() { public void run() { removeRoom(); } }));
        side.add(sideButton("Assign room to course", new Runnable() { public void run() { assignRoom(-1); } }));
        side.add(sideButton("Unassign room", new Runnable() { public void run() { unassignRoom(); } }));

        side.add(sideHeader("TIMETABLE"));
        side.add(sideButton("Add class session", new Runnable() { public void run() { addSession(); } }));
        side.add(sideButton("Add generate request", new Runnable() { public void run() { addRequest(-1, -1); } }));
        strategyBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        strategyBox.setAlignmentX(Component.LEFT_ALIGNMENT);
        side.add(Box.createVerticalStrut(4));
        side.add(strategyBox);
        side.add(sideButton("Auto-generate (" + TimetableStore.BREAK_HOURS + "h break)",
                new Runnable() { public void run() { generate(); } }));
        side.add(sideButton("Clear timetable", new Runnable() { public void run() { clearTimetable(); } }));

        side.add(sideHeader("OUTPUT"));
        side.add(sideButton("Export to CSV", new Runnable() { public void run() { exportCsv(); } }));

        side.add(Box.createVerticalGlue());
        side.add(sideButton("Exit", new Runnable() { public void run() { System.exit(0); } }));
        return side;
    }

    private JLabel sideHeader(String text) {
        JLabel l = new JLabel(text);
        l.setFont(l.getFont().deriveFont(java.awt.Font.BOLD, 11f));
        l.setForeground(new Color(0x5A6678));
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        l.setBorder(BorderFactory.createEmptyBorder(12, 2, 4, 0));
        return l;
    }

    private JButton sideButton(String text, final Runnable action) {
        JButton b = new JButton(text);
        b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        b.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) { runIfIdle(action); }
        });
        return b;
    }

    //  centre: timetable table + master data
    private JTabbedPane buildCentre() {
        tableModel = new DefaultTableModel(TimetableStore.timetableHeaders(), 0) {
            private static final long serialVersionUID = 1L;
            public boolean isCellEditable(int row, int column) { return false; }
        };
        JTable table = new JTable(tableModel);
        table.setRowHeight(24);
        table.setAutoCreateRowSorter(true);

        JPanel data = new JPanel(new GridLayout(2, 2, 8, 8));
        data.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        data.add(listPanel("Courses", courseModel));
        data.add(listPanel("Lecturers", lecturerModel));
        data.add(listPanel("Student groups", groupModel));
        data.add(listPanel("Rooms", roomModel));

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Timetable", new JScrollPane(table));
        tabs.addTab("Master data", data);
        tabs.addTab("Room assignments", listPanel("Course -> assigned rooms", assignmentModel));   // NEW
        return tabs;
    }

    private JPanel listPanel(String title, DefaultListModel<String> model) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createTitledBorder(title));
        p.add(new JScrollPane(new JList<String>(model)), BorderLayout.CENTER);
        return p;
    }

    //  bottom status bar 
    private JPanel buildStatusBar() {
        progressBar.setStringPainted(true);
        progressBar.setPreferredSize(new Dimension(180, 18));

        JPanel bar = new JPanel(new BorderLayout(10, 0));
        bar.setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 10));
        bar.add(statusLabel, BorderLayout.CENTER);
        bar.add(progressBar, BorderLayout.EAST);
        return bar;
    }

    /** Reloads the table, the lists and the status bar from the store. Call after every change. */
    private void refresh() {
        tableModel.setRowCount(0);
        for (String[] row : store.timetableRows()) tableModel.addRow(row);

        fill(courseModel, store.courseLines());
        fill(lecturerModel, store.lecturerLines());
        fill(groupModel, store.groupLines());
        fill(roomModel, store.roomLines());
        fill(assignmentModel, store.assignmentLines());   // NEW

        statusLabel.setText("Courses: " + courseModel.size()
                + "   Lecturers: " + lecturerModel.size() + "/" + TimetableStore.MAX_LECTURERS
                + "   Groups: " + groupModel.size() + "/" + TimetableStore.MAX_GROUPS
                + "   Requests: " + store.requestCount()
                + "   Sessions in timetable: " + store.sessionCount());
    }

    private static void fill(DefaultListModel<String> model, List<String> lines) {
        model.clear();
        for (String line : lines) model.addElement(line);
    }


    // ========================================
    //  2. ACTIONS (one per button / menu item)
    // ========================================
    // courses 
    private void addCourse() {
        JTextField code = new JTextField(12);
        JTextField name = new JTextField(20);
        JCheckBox lab = new JCheckBox("Needs a laboratory");
        Object[] form = {"Course code (e.g. CS105):", code, "Course name:", name, lab};
        if (!showForm("Add course", form)) return;
        try {
            int index = store.addCourse(code.getText(), name.getText(), lab.isSelected());
            refresh();
            if (askYesNo("Course added. Add an auto-generate request for it now?")) addRequest(index, -1);
        } catch (Exception e) {
            error("Could not add course: " + e.getMessage());
        }
    }

    private void removeCourse() {
        try {
            int i = pick("Remove course", "Which course?", store.courseLines());
            if (i < 0) return;
            int impact = store.courseImpact(i);
            if (impact > 0 && !askYesNo("This also deletes " + impact + " scheduled session(s)/request(s) of "
                    + store.courseLines().get(i) + ".\nContinue?")) return;
            store.removeCourse(i);
            refresh();
        } catch (Exception e) {
            error("Could not remove course: " + e.getMessage());
        }
    }

    //  lecturers
    private void addLecturer() {
        JTextField id = new JTextField(12);
        JTextField name = new JTextField(20);
        Object[] form = {"Lecturer ID (e.g. L4):", id, "Lecturer name:", name};
        if (!showForm("Add lecturer", form)) return;
        try {
            store.addLecturer(id.getText(), name.getText());
            refresh();
        } catch (Exception e) {
            error("Could not add lecturer: " + e.getMessage());
        }
    }

    private void removeLecturer() {
        try {
            int i = pick("Remove lecturer", "Which lecturer?", store.lecturerLines());
            if (i < 0) return;
            int impact = store.lecturerImpact(i);
            if (impact > 0 && !askYesNo("This also deletes " + impact + " scheduled session(s)/request(s) taught by "
                    + store.lecturerLines().get(i) + ".\nContinue?")) return;
            store.removeLecturer(i);
            refresh();
        } catch (Exception e) {
            error("Could not remove lecturer: " + e.getMessage());
        }
    }

    // student groups 
    private void addGroup() {
        JTextField id = new JTextField(12);
        JSpinner size = new JSpinner(new SpinnerNumberModel(30, 1, 500, 1));
        Object[] form = {"Group ID (e.g. G3):", id, "Number of students:", size};
        if (!showForm("Add student group", form)) return;
        try {
            int index = store.addGroup(id.getText(), ((Integer) size.getValue()).intValue());
            refresh();
            // a group only gets classes if it has requests, so offer to add them straight away
            if (askYesNo("Group added. Add courses for this group to auto-generate now?")) {
                do {
                    if (!addRequest(-1, index)) break;
                } while (askYesNo("Add another course for this group?"));
            }
        } catch (Exception e) {
            error("Could not add group: " + e.getMessage());
        }
    }

    private void removeGroup() {
        try {
            int i = pick("Remove student group", "Which group?", store.groupLines());
            if (i < 0) return;
            int impact = store.groupImpact(i);
            if (impact > 0 && !askYesNo("This also deletes " + impact + " scheduled session(s)/request(s) of "
                    + store.groupLines().get(i) + ".\nContinue?")) return;
            store.removeGroup(i);
            refresh();
        } catch (Exception e) {
            error("Could not remove group: " + e.getMessage());
        }
    }

    // rooms (NEW)
    private void addRoom() {
        JTextField id = new JTextField(12);
        JTextField name = new JTextField(20);
        JSpinner capacity = new JSpinner(new SpinnerNumberModel(30, 1, 500, 1));
        JCheckBox lab = new JCheckBox("This is a laboratory");
        Object[] form = {"Room ID (e.g. R3):", id, "Room name:", name, "Capacity:", capacity, lab};
        if (!showForm("Add room", form)) return;
        try {
            int index = store.addRoom(id.getText(), name.getText(),
                    ((Integer) capacity.getValue()).intValue(), lab.isSelected());
            refresh();
            if (askYesNo("Room added. Assign it to courses now?")) {
                do {
                    if (!assignRoom(index)) break;
                } while (askYesNo("Assign this room to another course?"));
            }
        } catch (Exception e) {
            error("Could not add room: " + e.getMessage());
        }
    }

    private void removeRoom() {
        try {
            int i = pick("Remove room", "Which room?", store.roomLines());
            if (i < 0) return;
            int impact = store.roomImpact(i);
            if (impact > 0 && !askYesNo("This also deletes " + impact + " scheduled session(s) in "
                    + store.roomLines().get(i) + ".\nContinue?")) return;
            store.removeRoom(i);
            refresh();
        } catch (Exception e) {
            error("Could not remove room: " + e.getMessage());
        }
    }

    /** Pass a room index to preset and lock the room, or -1 to choose. Returns true if assigned. */
    private boolean assignRoom(int presetRoom) {
        if (store.courseLines().isEmpty() || store.roomLines().isEmpty()) {
            error("You need at least one course and one room first.");
            return false;
        }
        JComboBox<String> course = combo(store.courseLines(), -1);
        JComboBox<String> room = combo(store.roomLines(), presetRoom);
        Object[] form = {"Course:", course, "Room:", room};
        if (!showForm("Assign room to course", form)) return false;
        try {
            store.assignRoom(course.getSelectedIndex(), room.getSelectedIndex());
            refresh();
            return true;
        } catch (Exception e) {
            error("Could not assign room: " + e.getMessage());
            return false;
        }
    }

    private void unassignRoom() {
        if (store.courseLines().isEmpty() || store.roomLines().isEmpty()) {
            error("Nothing to unassign.");
            return;
        }
        JComboBox<String> course = combo(store.courseLines(), -1);
        JComboBox<String> room = combo(store.roomLines(), -1);
        Object[] form = {"Course:", course, "Room:", room};
        if (!showForm("Unassign room from course", form)) return;
        try {
            store.unassignRoom(course.getSelectedIndex(), room.getSelectedIndex());
            refresh();
        } catch (Exception e) {
            error("Could not unassign: " + e.getMessage());
        }
    }

    // requests (what auto-generate must place) 
    /**
     * Asks course / lecturer / group / hours and saves a request.
     * Pass an index (0, 1, 2) to preset and lock the course or the group, or -1 to let the user choose.
     * Returns true if a request was added.
     */
    private boolean addRequest(int presetCourse, int presetGroup) {
        if (store.courseLines().isEmpty() || store.lecturerLines().isEmpty() || store.groupLines().isEmpty()) {
            error("You need at least one course, lecturer and group first.");
            return false;
        }
        JComboBox<String> course = combo(store.courseLines(), presetCourse);
        JComboBox<String> lecturer = combo(store.lecturerLines(), -1);
        JComboBox<String> group = combo(store.groupLines(), presetGroup);
        JSpinner hours = new JSpinner(new SpinnerNumberModel(2, 1, 10, 1));
        Object[] form = {"Course:", course, "Lecturer:", lecturer, "Student group:", group, "Hours per week:", hours};
        if (!showForm("Add auto-generate request", form)) return false;
        try {
            store.addRequest(course.getSelectedIndex(), lecturer.getSelectedIndex(), group.getSelectedIndex(),
                    ((Integer) hours.getValue()).intValue());
            refresh();
            return true;
        } catch (Exception e) {
            error("Could not add request: " + e.getMessage());
            return false;
        }
    }

    // add a class session (with conflict check)
    private void addSession() {
        if (store.courseLines().isEmpty() || store.lecturerLines().isEmpty()
                || store.groupLines().isEmpty() || store.roomLines().isEmpty()) {
            error("You need at least one course, lecturer, group and room first.");
            return;
        }
        JComboBox<String> course = combo(store.courseLines(), -1);
        JComboBox<String> lecturer = combo(store.lecturerLines(), -1);
        JComboBox<String> group = combo(store.groupLines(), -1);
        JComboBox<String> room = combo(store.roomLines(), -1);
        JComboBox<String> day = new JComboBox<String>(
                new String[]{"MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY"});
        JTextField start = new JTextField("08:00", 8);
        JTextField end = new JTextField("10:00", 8);
        Object[] form = {"Course:", course, "Lecturer:", lecturer, "Student group:", group, "Room:", room,
                "Day:", day, "Start time (HH:mm):", start, "End time (HH:mm):", end};
        if (!showForm("Add class session", form)) return;
        try {
            List<String> conflicts = store.addSession(course.getSelectedIndex(), lecturer.getSelectedIndex(),
                    group.getSelectedIndex(), room.getSelectedIndex(),
                    (String) day.getSelectedItem(), start.getText(), end.getText());
            if (conflicts.isEmpty()) {
                refresh();
                JOptionPane.showMessageDialog(this, "Session added.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                StringBuilder sb = new StringBuilder("REJECTED, " + conflicts.size() + " conflict(s):\n");
                for (String m : conflicts) sb.append("\n  - ").append(m);
                JOptionPane.showMessageDialog(this, sb.toString(), "Conflict", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception e) {
            error("Invalid input: " + e.getMessage());
        }
    }

    //  auto-generate (runs on a background thread so the window stays responsive) 
    private void generate() {
        final int strategy = strategyBox.getSelectedIndex();
        busy = true;
        progressBar.setValue(0);
        statusLabel.setText("Generating with " + strategyBox.getSelectedItem() + "...");

        new SwingWorker<TimetableStore.ScheduleResult, Integer>() {
            protected TimetableStore.ScheduleResult doInBackground() {
                return store.generate(strategy, new TimetableStore.ProgressListener() {
                    public void onProgress(int percent) { publish(Integer.valueOf(percent)); }
                });
            }

            protected void process(List<Integer> chunks) {
                progressBar.setValue(chunks.get(chunks.size() - 1).intValue());
            }

            protected void done() {
                busy = false;
                try {
                    TimetableStore.ScheduleResult r = get();
                    progressBar.setValue(100);
                    refresh();
                    String msg = "Placed: " + r.placedCount() + "   Unscheduled: " + r.unscheduledCount();
                    for (String label : r.unscheduledLabels()) msg += "\n  could not place " + label;
                    JOptionPane.showMessageDialog(TimetableGUI.this, msg, "Auto-generate finished",
                            r.unscheduledCount() == 0 ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.WARNING_MESSAGE);
                } catch (Exception e) {
                    error("Auto-generate failed: " + e.getMessage());
                }
            }
        }.execute();
    }

    //  clear timetable
    private void clearTimetable() {
        int n = store.sessionCount();
        if (n == 0) {
            error("The timetable is already empty.");
            return;
        }
        if (!askYesNo("This deletes all " + n + " scheduled session(s).\nCourses, rooms and requests are kept.\nContinue?")) return;
        try {
            store.clearTimetable();
            refresh();
        } catch (Exception e) {
            error("Could not clear timetable: " + e.getMessage());
        }
    }

    //  export 
    private void exportCsv() {
        if (store.sessionCount() == 0) {
            error("Nothing to export: the timetable is empty. Add sessions or auto-generate first.");
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("timetable.csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        String path = chooser.getSelectedFile().getPath();
        if (!path.toLowerCase().endsWith(".csv")) path += ".csv";
        try {
            File f = store.exportCsv(path);
            JOptionPane.showMessageDialog(this, "Exported " + store.sessionCount() + " sessions to:\n"
                    + f.getAbsolutePath(), "Export done", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            error("Export failed: " + e.getMessage());
        }
    }

    private void about() {
        JOptionPane.showMessageDialog(this,
                "Academic Timetabling System\n\n"
                + "Max lecturers: " + TimetableStore.MAX_LECTURERS + "\n"
                + "Max student groups: " + TimetableStore.MAX_GROUPS + "\n"
                + "Auto-generate keeps a " + TimetableStore.BREAK_HOURS
                + " hour break between classes of the same group or lecturer.",
                "About", JOptionPane.INFORMATION_MESSAGE);
    }


    // =========================
    //  3. SMALL DIALOG HELPERS
    // =========================
    /** Blocks changes while auto-generate is running. */
    private void runIfIdle(Runnable action) {
        if (busy) {
            JOptionPane.showMessageDialog(this, "Please wait, auto-generate is still running.");
            return;
        }
        action.run();
    }

    private boolean showForm(String title, Object[] form) {
        return JOptionPane.showConfirmDialog(this, form, title,
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE) == JOptionPane.OK_OPTION;
    }

    /** A drop-down of the lines. If preset >= 0 that item is selected and the box is locked. */
    private JComboBox<String> combo(List<String> lines, int preset) {
        JComboBox<String> box = new JComboBox<String>(lines.toArray(new String[0]));
        if (preset >= 0) {
            box.setSelectedIndex(preset);
            box.setEnabled(false);
        }
        return box;
    }

    /** Shows a drop-down and returns the chosen position, or -1 if cancelled or the list is empty. */
    private int pick(String title, String label, List<String> lines) {
        if (lines.isEmpty()) {
            error("Nothing to choose from.");
            return -1;
        }
        JComboBox<String> box = combo(lines, -1);
        Object[] form = {label, box};
        return showForm(title, form) ? box.getSelectedIndex() : -1;
    }

    private boolean askYesNo(String question) {
        return JOptionPane.showConfirmDialog(this, question, "Confirm",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    private void error(String message) {
        JOptionPane.showMessageDialog(this, message, "Problem", JOptionPane.ERROR_MESSAGE);
    }


    // =============================
    //  4. MAIN  <-- run this class
    // =============================
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // keep the default look if the system one is not available
        }
        SwingUtilities.invokeLater(new Runnable() {
            public void run() { new TimetableGUI().setVisible(true); }
        });
    }
}