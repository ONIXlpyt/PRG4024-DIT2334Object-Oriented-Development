/**
 * 
 */
/**
 * 
 */
module first_test {
	requires java.desktop;
	requires java.sql;
}